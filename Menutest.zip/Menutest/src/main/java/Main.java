import ui.demomenu.DemoMenu;

public class Main {
    public static void main(String args[]){
        System.out.println("This is a demo for the menu developing");
        new DemoMenu();
    }
}
